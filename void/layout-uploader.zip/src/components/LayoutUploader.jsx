import React, { useState } from 'react';
import axios from 'axios';

function LayoutUploader() {
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);

  const handleFileChange = (e) => {
    setImage(e.target.files[0]);
  };

  const handleUpload = async () => {
    if (!image) return;
    const formData = new FormData();
    formData.append('file', image);

    try {
      const res = await axios.post(`${process.env.REACT_APP_API_URL}/layout`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setResult(res.data);
    } catch (err) {
      alert('업로드 실패!');
      console.error(err);
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>부모님 동선 배치 시뮬레이터</h2>
      <input type="file" onChange={handleFileChange} accept="image/*" />
      <button onClick={handleUpload}>분석 요청</button>

      {result && (
        <div>
          <h3>분석 결과:</h3>
          <pre>{JSON.stringify(result, null, 2)}</pre>
          {result.parent_warnings.length > 0 && (
            <div style={{ color: 'red' }}>
              <h4>부모님 주의 사항</h4>
              <ul>
                {result.parent_warnings.map((w, idx) => <li key={idx}>⚠ {w}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default LayoutUploader;
