import React from 'react';
import LayoutUploader from './components/LayoutUploader';

function App() {
  return <LayoutUploader />;
}

export default App;
